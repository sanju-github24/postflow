const axios = require('axios');
const { decrypt } = require('../utils/encryption');

// ── Facebook: Supports Link-based uploads ─────────────────────────────────────
const postToFacebook = async (account, content, fileUrl) => {
  const token = decrypt(account.access_token);
  const pageId = account.page_id;
  
  let endpoint = `https://graph.facebook.com/v18.0/${pageId}/feed`;
  let payload = { message: content, access_token: token };

  // If there's a file, change endpoint/payload based on type
  if (fileUrl) {
    const isVideo = fileUrl.match(/\.(mp4|mov|avi)$/i);
    endpoint = `https://graph.facebook.com/v18.0/${pageId}/${isVideo ? 'videos' : 'photos'}`;
    payload[isVideo ? 'description' : 'caption'] = content;
    payload[isVideo ? 'file_url' : 'url'] = fileUrl;
  }

  const res = await axios.post(endpoint, payload);
  return res.data.id || res.data.post_id;
};

// ── Instagram: Two-step Container Process ──────────────────────────────────────
const postToInstagram = async (account, content, fileUrl) => {
  const token = decrypt(account.access_token);
  const igId = account.page_id;

  if (!fileUrl) throw new Error("Instagram requires an image or video");

  const isVideo = fileUrl.match(/\.(mp4|mov|avi)$/i);
  
  // 1. Create Media Container
  const containerRes = await axios.post(`https://graph.facebook.com/v18.0/${igId}/media`, {
    [isVideo ? 'video_url' : 'image_url']: fileUrl,
    caption: content,
    media_type: isVideo ? 'REELS' : 'IMAGE',
    access_token: token,
  });

  const creationId = containerRes.data.id;

  // 2. Wait for processing (especially for Video/Reels)
  // In production, you'd poll /IG_USER_ID/media_publish_status
  
  // 3. Publish Container
  const publishRes = await axios.post(`https://graph.facebook.com/v18.0/${igId}/media_publish`, {
    creation_id: creationId,
    access_token: token,
  });

  return publishRes.data.id;
};

// ── Twitter: URL-based tweeting ───────────────────────────────────────────────
const postToTwitter = async (account, content, fileUrl) => {
  const token = decrypt(account.access_token);
  
  // Twitter API v2 doesn't "fetch" from a URL directly like Meta. 
  // For a simple MVP, we append the URL to the text so Twitter generates a card.
  // For native upload, you'd need the 'twitter-api-v2' library and buffer downloads.
  let tweetText = content;
  if (fileUrl) {
    tweetText = `${content}\n\n${fileUrl}`;
  }

  const tweet = tweetText.length > 280 ? tweetText.slice(0, 277) + '...' : tweetText;
  
  const res = await axios.post(
    'https://api.twitter.com/2/tweets',
    { text: tweet },
    { headers: { Authorization: `Bearer ${token}` } }
  );
  return res.data.data.id;
};

// ── Main Router ───────────────────────────────────────────────────────────────
const publish = async (platform, account, content, fileUrl = null) => {
  switch (platform) {
    case 'facebook':  return postToFacebook(account, content, fileUrl);
    case 'instagram': return postToInstagram(account, content, fileUrl);
    case 'twitter':   return postToTwitter(account, content, fileUrl);
    default: throw new Error(`Unknown platform: ${platform}`);
  }
};

module.exports = { publish };